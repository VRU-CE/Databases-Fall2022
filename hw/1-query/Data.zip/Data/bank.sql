CREATE SCHEMA IF NOT EXISTS bank
    AUTHORIZATION postgres;
	
CREATE TABLE bank.branch
(
    branch_name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    branch_city character varying(100) COLLATE pg_catalog."default" NOT NULL,
    assets double precision DEFAULT 0,
    CONSTRAINT branch_pkey PRIMARY KEY (branch_name)
);

CREATE TABLE bank.account
(
    account_number character varying(50) COLLATE pg_catalog."default" NOT NULL,
    branch_name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    balance double precision DEFAULT 0,
    CONSTRAINT account_pkey PRIMARY KEY (account_number),
    CONSTRAINT account_branch_name_fkey FOREIGN KEY (branch_name)
        REFERENCES bank.branch (branch_name) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

CREATE TABLE bank.customer
(
    customer_name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    customer_street character varying(100) COLLATE pg_catalog."default",
    customer_city character varying(50) COLLATE pg_catalog."default",
    CONSTRAINT customer_pkey PRIMARY KEY (customer_name)
);

CREATE TABLE bank.loan
(
    loan_number character varying(50) COLLATE pg_catalog."default" NOT NULL,
    branch_name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    amount double precision DEFAULT 0,
    CONSTRAINT loan_pkey PRIMARY KEY (loan_number),
    CONSTRAINT loan_branch_name_fkey FOREIGN KEY (branch_name)
        REFERENCES bank.branch (branch_name) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

CREATE TABLE bank.depositor
(
    customer_name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    account_number character varying(50) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT depositor_pkey PRIMARY KEY (customer_name, account_number),
    CONSTRAINT depositor_account_number_fkey FOREIGN KEY (account_number)
        REFERENCES bank.account (account_number) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT depositor_customer_name_fkey FOREIGN KEY (customer_name)
        REFERENCES bank.customer (customer_name) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

CREATE TABLE bank.borrower
(
    customer_name character varying(100) COLLATE pg_catalog."default" NOT NULL,
    loan_number character varying(50) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT borrower_pkey PRIMARY KEY (customer_name, loan_number),
    CONSTRAINT borrower_customer_name_fkey FOREIGN KEY (customer_name)
        REFERENCES bank.customer (customer_name) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT borrower_loan_number_fkey FOREIGN KEY (loan_number)
        REFERENCES bank.loan (loan_number) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
);

INSERT INTO bank.branch(branch_name, branch_city, assets)
	VALUES ('Azadi', 'Tehran', 100);
INSERT INTO bank.branch(branch_name, branch_city, assets)
	VALUES ('Emam', 'Kerman', 10);
INSERT INTO bank.branch(branch_name, branch_city, assets)
	VALUES ('Pirouzi', 'Isfahan', 15);
INSERT INTO bank.branch(branch_name, branch_city, assets)
	VALUES ('Hemat', 'Shiraz', 35);
INSERT INTO bank.branch(branch_name, branch_city, assets)
	VALUES ('Safa', 'Mashhad', 50);

INSERT INTO bank.account(account_number, branch_name, balance)
	VALUES (3367, 'Azadi', 400);
INSERT INTO bank.account(account_number, branch_name, balance)
	VALUES (3360, 'Azadi', 30);
INSERT INTO bank.account(account_number, branch_name, balance)
	VALUES (4100, 'Emam', 300);
INSERT INTO bank.account(account_number, branch_name, balance)
	VALUES (4200, 'Emam', 30);
INSERT INTO bank.account(account_number, branch_name, balance)
	VALUES (5100, 'Pirouzi', 20);
INSERT INTO bank.account(account_number, branch_name, balance)
	VALUES (5610, 'Pirouzi', 38);
INSERT INTO bank.account(account_number, branch_name, balance)
	VALUES (5709, 'Pirouzi', 73);
INSERT INTO bank.account(account_number, branch_name, balance)
	VALUES (6309, 'Hemat', 73);
INSERT INTO bank.account(account_number, branch_name, balance)
	VALUES (6400, 'Hemat', 20);
INSERT INTO bank.account(account_number, branch_name, balance)
	VALUES (6708, 'Hemat', 80);
INSERT INTO bank.account(account_number, branch_name, balance)
	VALUES (6609, 'Hemat', 73);
INSERT INTO bank.account(account_number, branch_name, balance)
	VALUES (7309, 'Safa', 73);
INSERT INTO bank.account(account_number, branch_name, balance)
	VALUES (7600, 'Safa', 99);
INSERT INTO bank.account(account_number, branch_name, balance)
	VALUES (7909, 'Safa', 32);
INSERT INTO bank.account(account_number, branch_name, balance)
	VALUES (7201, 'Safa', 61);
INSERT INTO bank.account(account_number, branch_name, balance)
	VALUES (7555, 'Safa', 54);

INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Alavi', 'Enghelab', 'Shiraz');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Ahmadi', 'Bostan', 'Ahwaz');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Moradi', 'Shafagh', 'Tehran');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Karimi', 'Ketab', 'Semnan');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Eghbali', 'Vahdat', 'Bam');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Sohrabi', 'Dasht', 'Jiroft');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Saberi', 'Kowsar', 'Sirjan');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Jamali', 'Bahar', 'Rafsanjan');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Kabiri', 'Ziba', 'Arak');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Soltani', 'Fasl', 'Hamedan');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Majidi', 'Doust', 'Tabriz');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Arbabi', 'Shahid', 'Rashd');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Bahmani', 'Sarbaz', 'Karaj');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Hamidi', 'Kavir', 'Yazd');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Hosseini', 'Rasta', 'Bandar');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Arab', 'Sobh', 'Kermanshah');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Pahlavan', 'Jangal', 'Isfahan');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Naseri', 'Darakht', 'Rafsanjan');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Rezaie', 'Sabz', 'Kerman');
INSERT INTO bank.customer(customer_name, customer_street, customer_city)
	VALUES ('Tavakol', 'Sepid', 'Shiraz');

INSERT INTO bank.loan(loan_number, branch_name, amount)
	VALUES (12201, 'Azadi', 24);
INSERT INTO bank.loan(loan_number, branch_name, amount)
	VALUES (13204, 'Azadi', 94);
INSERT INTO bank.loan(loan_number, branch_name, amount)
	VALUES (21200, 'Emam', 34);
INSERT INTO bank.loan(loan_number, branch_name, amount)
	VALUES (21701, 'Emam', 67);
INSERT INTO bank.loan(loan_number, branch_name, amount)
	VALUES (31207, 'Pirouzi', 89);
INSERT INTO bank.loan(loan_number, branch_name, amount)
	VALUES (32208, 'Pirouzi', 39);
INSERT INTO bank.loan(loan_number, branch_name, amount)
	VALUES (31701, 'Pirouzi', 90);
INSERT INTO bank.loan(loan_number, branch_name, amount)
	VALUES (32209, 'Pirouzi', 64);
INSERT INTO bank.loan(loan_number, branch_name, amount)
	VALUES (41203, 'Hemat', 92);
INSERT INTO bank.loan(loan_number, branch_name, amount)
	VALUES (41316, 'Hemat', 33);
INSERT INTO bank.loan(loan_number, branch_name, amount)
	VALUES (43481, 'Hemat', 78);
INSERT INTO bank.loan(loan_number, branch_name, amount)
	VALUES (51931, 'Safa', 45);
INSERT INTO bank.loan(loan_number, branch_name, amount)
	VALUES (52519, 'Safa', 78);



INSERT INTO bank.depositor(customer_name, account_number)
	VALUES ('Ahmadi', 3360);
INSERT INTO bank.depositor(customer_name, account_number)
	VALUES ('Alavi', 3367);
INSERT INTO bank.depositor(customer_name, account_number)
	VALUES ('Arbabi', 4200);
INSERT INTO bank.depositor(customer_name, account_number)
	VALUES ('Bahmani', 5100);
INSERT INTO bank.depositor(customer_name, account_number)
	VALUES ('Eghbali', 5610);
INSERT INTO bank.depositor(customer_name, account_number)
	VALUES ('Hosseini', 6309);
INSERT INTO bank.depositor(customer_name, account_number)
	VALUES ('Jamali', 6400);
INSERT INTO bank.depositor(customer_name, account_number)
	VALUES ('Karimi', 6708);
INSERT INTO bank.depositor(customer_name, account_number)
	VALUES ('Majidi', 7201);
INSERT INTO bank.depositor(customer_name, account_number)
	VALUES ('Moradi', 7555);
INSERT INTO bank.depositor(customer_name, account_number)
	VALUES ('Naseri', 7600);
INSERT INTO bank.depositor(customer_name, account_number)
	VALUES ('Pahlavan', 7909);
INSERT INTO bank.depositor(customer_name, account_number)
	VALUES ('Rezaie', 4100);
INSERT INTO bank.depositor(customer_name, account_number)
	VALUES ('Saberi', 5709);
INSERT INTO bank.depositor(customer_name, account_number)
	VALUES ('Sohrabi', 7309);
INSERT INTO bank.depositor(customer_name, account_number)
	VALUES ('Soltani', 6609);

INSERT INTO bank.borrower(customer_name, loan_number)
	VALUES ('Ahmadi', 21701);
INSERT INTO bank.borrower(customer_name, loan_number)
	VALUES ('Alavi', 31207);
INSERT INTO bank.borrower(customer_name, loan_number)
	VALUES ('Arab', 12201);
INSERT INTO bank.borrower(customer_name, loan_number)
	VALUES ('Arbabi', 51931);
INSERT INTO bank.borrower(customer_name, loan_number)
	VALUES ('Eghbali', 41316);
INSERT INTO bank.borrower(customer_name, loan_number)
	VALUES ('Hamidi', 43481);
INSERT INTO bank.borrower(customer_name, loan_number)
	VALUES ('Hosseini', 31701);
INSERT INTO bank.borrower(customer_name, loan_number)
	VALUES ('Kabiri', 13204);
INSERT INTO bank.borrower(customer_name, loan_number)
	VALUES ('Moradi', 52519);
INSERT INTO bank.borrower(customer_name, loan_number)
	VALUES ('Naseri', 32208);
INSERT INTO bank.borrower(customer_name, loan_number)
	VALUES ('Pahlavan', 32209);
INSERT INTO bank.borrower(customer_name, loan_number)
	VALUES ('Rezaie', 41203);
INSERT INTO bank.borrower(customer_name, loan_number)
	VALUES ('Tavakol', 21200);
	