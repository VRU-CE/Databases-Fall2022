CREATE SCHEMA IF NOT EXISTS sailor
    AUTHORIZATION postgres;
	
CREATE TABLE sailor."Sailors"
(
    sid character varying(50) COLLATE pg_catalog."default" NOT NULL,
    sname character varying(50) COLLATE pg_catalog."default" NOT NULL,
    rating integer,
    age double precision,
    CONSTRAINT "Sailors_pkey" PRIMARY KEY (sid)
);

CREATE TABLE sailor."Boats"
(
    bid character varying(50) COLLATE pg_catalog."default" NOT NULL,
    bname character varying(50) COLLATE pg_catalog."default" NOT NULL,
    color character varying(50) COLLATE pg_catalog."default",
    CONSTRAINT "Boats_pkey" PRIMARY KEY (bid)
);

CREATE TABLE sailor."Reservations"
(
    sid character varying(50) COLLATE pg_catalog."default" NOT NULL,
    bid character varying(50) COLLATE pg_catalog."default" NOT NULL,
    day date NOT NULL,
    CONSTRAINT "Reservations_pkey" PRIMARY KEY (day, bid, sid),
    CONSTRAINT "Reservations_bid_fkey" FOREIGN KEY (bid)
        REFERENCES sailor."Boats" (bid) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE,
    CONSTRAINT "Reservations_sid_fkey" FOREIGN KEY (sid)
        REFERENCES sailor."Sailors" (sid) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

INSERT INTO sailor."Sailors"(
	sid, sname, rating, age)
	VALUES (22, 'dustin', 7, 45);
INSERT INTO sailor."Sailors"(
	sid, sname, rating, age)
	VALUES (29, 'brutus', 1, 33);
INSERT INTO sailor."Sailors"(
	sid, sname, rating, age)
	VALUES (31, 'lubber', 8, 55.5);
INSERT INTO sailor."Sailors"(
	sid, sname, rating, age)
	VALUES (32, 'andy', 8, 25.5);
INSERT INTO sailor."Sailors"(
	sid, sname, rating, age)
	VALUES (58, 'rusty', 10, 35);
INSERT INTO sailor."Sailors"(
	sid, sname, rating, age)
	VALUES (64, 'horatio', 7, 35);
INSERT INTO sailor."Sailors"(
	sid, sname, rating, age)
	VALUES (71, 'zorba', 10, 16);
INSERT INTO sailor."Sailors"(
	sid, sname, rating, age)
	VALUES (85, 'art', 3, 25.5);
INSERT INTO sailor."Sailors"(
	sid, sname, rating, age)
	VALUES (74, 'horatio', 9, 35);
INSERT INTO sailor."Sailors"(
	sid, sname, rating, age)
	VALUES (95, 'bob', 3, 63.5);
INSERT INTO sailor."Sailors"(
	sid, sname, rating, age)
	VALUES (96, 'frodo', 3, 25.5);

INSERT INTO sailor."Boats"(bid, bname, color)
	VALUES (101, 'Interlake', 'blue');
INSERT INTO sailor."Boats"(bid, bname, color)
	VALUES (102, 'Interlake', 'red');
INSERT INTO sailor."Boats"(bid, bname, color)
	VALUES (103, 'Clipper', 'green');
INSERT INTO sailor."Boats"(bid, bname, color)
	VALUES (104, 'Marine', 'red');

INSERT INTO sailor."Reservations"(sid, bid, day)
	VALUES (22, 101, '10/10/96');
INSERT INTO sailor."Reservations"(sid, bid, day)
	VALUES (58, 103, '11/12/96');
INSERT INTO sailor."Reservations"(sid, bid, day)
	VALUES (58, 102, '10/20/98');
